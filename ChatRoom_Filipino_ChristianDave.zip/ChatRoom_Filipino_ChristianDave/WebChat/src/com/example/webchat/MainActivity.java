package com.example.webchat;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



import android.os.Bundle;
import android.os.StrictMode;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener, android.content.DialogInterface.OnClickListener {
	//String url="";
	WebView wv;
	//TextView Tname;
	ImageView btnSend;
	EditText txtmessage, txtname,txtIpAdd;
	String ip="172.19.131.79";
	String link;
	
	
	AlertDialog.Builder builder;
	AlertDialog dialog;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        
        this.wv = (WebView) this.findViewById(R.id.webView1);
        this.btnSend = (ImageView) this.findViewById(R.id.imageView1);
        this.txtmessage = (EditText) this.findViewById(R.id.editText1);
        this.txtname = (EditText) this.findViewById(R.id.editText2);
      //  this.Tname = (TextView) this.findViewById(R.id.textView1);
      //  this.Tname.setOnClickListener(this);
        this.btnSend.setOnClickListener(this);
        
        if(this.txtname.getText()==null)
        {
        	this.txtname.requestFocus();
        }
        
        //this.wv.loadUrl("http://172.19.131.79/summer/chatroom/posting.php");
        this.wv.loadUrl("http://"+ip+"/chatroom/posting.php");
        wv.setScrollY(wv.getBottom());
        
     
     
        
        
        
        
    }
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
		
	
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		txtIpAdd = new EditText(this);
		txtIpAdd.setPadding(10, 10, 10, 10);
		txtIpAdd.setHint("Enter Ip Address");
		
		builder = new AlertDialog.Builder(this);
		builder.setTitle("IP ADDRESS");
		builder.setView(txtIpAdd);
		builder.setPositiveButton("Set IP Address", this);
		builder.setNegativeButton("Cancel", this);
		
		dialog = builder.create();
		dialog.show();
		
		
		
		return super.onOptionsItemSelected(item);
	}
	@Override
	public void onClick(View arg0) {
		//int id = arg0.getId();
		// TODO Auto-generated method stub
		String message = this.txtmessage.getText().toString();
		String name = this.txtname.getText().toString();
		if(!message.equals("") && !name.equals(""))
		{
			//if(message.contains(" "))
		try {
			URL url=null;
			
			//String link = "http://172.19.131.79/summer/chatroom/sendmessage.php?name="+name+"&message="+message;
			link = "http://"+ip+"/chatroom/sendmessage.php?name="+name+"&message="+message;
			
			url = new URL(link.replaceAll(" ","%20")); 
			
			//send message to server
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			//get the server respond
			InputStream is = conn.getInputStream();
			StringBuffer sb = new StringBuffer();
			char ch ='\u0000';
			int n=0;
			while(n!=-1)
			{
				n=is.read();
				sb.append((char)n);
			}
			is.close();
			conn.disconnect();
			this.txtmessage.setText("");
			this.txtmessage.requestFocus();
			Toast.makeText(this, sb.toString(), Toast.LENGTH_SHORT).show();
			wv.scrollTo(0, wv.getBottom());
			//every send, update webview content
			wv.reload();
			
			
			
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		}
		
	}
	@Override
	public void onClick(DialogInterface arg0, int arg1) {
		// TODO Auto-generated method stub
		
		switch(arg1)
		{
		case DialogInterface.BUTTON_POSITIVE:
			ip = this.txtIpAdd.getText().toString();
			link.notifyAll();
			break;
			
		case DialogInterface.BUTTON_NEGATIVE:
			dialog.dismiss();
		}
		
	}

    
    
}
