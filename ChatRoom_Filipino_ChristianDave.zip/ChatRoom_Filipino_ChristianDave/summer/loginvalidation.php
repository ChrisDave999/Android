<?php
 if(!empty($_GET["username"])&& !empty($_GET["password"]))
	{
		$username=$_GET["username"];
		$password=$_GET["password"];
		//
		//using terniary operaor
		$message =($username=="babes" && $password=="dennis")?"LOGIN ACCEPTED":"INVALID PASSWORD";
		echo $message;

	}
	else echo "PLEASE FILL ALL FIELDS"

?>