package com.example.addperson;

public class Student {

}
