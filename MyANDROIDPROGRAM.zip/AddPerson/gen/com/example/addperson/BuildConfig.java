/** Automatically generated file. DO NOT MODIFY */
package com.example.addperson;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}