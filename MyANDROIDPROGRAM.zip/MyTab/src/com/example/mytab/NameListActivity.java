package com.example.mytab;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NameListActivity extends Activity {

	ListView lv;
	ArrayList<Person> list = new ArrayList<Person>();
	Myadapter adapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.namelist);
		
		/* list.add(new Person("Alpha"));
		list.add(new Person("Bravo"));
		list.add(new Person("Charlie"));
		list.add(new Person("Delta"));
		list.add(new Person("Echo"));
		list.add(new Person("Foxtrot"));
		list.add(new Person("Geronimo"));
		list.add(new Person("Hotel")); */
		
		
		this.adapter = new Myadapter(this,list);
		this.lv = (ListView) this.findViewById(R.id.listView1);
		this.lv.setAdapter(adapter);
		adapter.notifyDataSetChanged();
		
				
	}

}
