package com.example.mytab;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddNameActivity extends Activity implements OnClickListener {
	ArrayList<Person> list = new ArrayList<Person>();
	EditText txtName;
	Button btnOkay,btnCancel;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.addname);
		this.txtName = (EditText) this.findViewById(R.id.editText1);
		this.btnOkay = (Button) this.findViewById(R.id.button1);
		this.btnCancel = (Button) this.findViewById(R.id.button2);

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    StrictMode.setThreadPolicy(policy);
	    
		this.btnOkay.setOnClickListener(this);
		this.btnCancel.setOnClickListener(this);
	}


	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		int id = arg0.getId();
		switch(id)
		{
		case R.id.button1:
			String name = txtName.getText().toString();
			Toast.makeText(AddNameActivity.this,"Added Successfuly!", Toast.LENGTH_LONG).show();
			
			Intent intent = new Intent(AddNameActivity.this,MainActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
			startActivity(intent);
			break;
		
		case R.id.button2:
			this.txtName.setText("");
			this.txtName.requestFocus();
			break;
		}
	}

}
