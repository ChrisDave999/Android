package com.example.locationtabs;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NameListActivity extends Activity {

	ListView lv;
	ArrayList<location> list = new ArrayList<location>();
	MyAdapter adapter;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.namelist);
	/*	list.add("Alpha");
		list.add("Bravo");
		list.add("Charlie");
		list.add("Delta");
		list.add("Echo");
		list.add("Foxtrot");
		*/
		adapter = new MyAdapter(this,list);
		this.lv = (ListView) this.findViewById(R.id.listView1);
		this.lv.setAdapter(adapter);
		adapter.notifyDataSetChanged();
	}

}
