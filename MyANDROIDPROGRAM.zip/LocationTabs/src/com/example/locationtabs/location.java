package com.example.locationtabs;

public class location {
	private String txtLat;
	private String txtLng;
	public String getLat() {
		return txtLat;
	}
	public void setLat(String txtLat) {
		this.txtLat = txtLat;
	}
	public String getLng() {
		return txtLng;
	}
	public void setLng(String txtLng) {
		this.txtLng = txtLng;
	}
	public location(String txtLat, String txtLng) {
		super();
		this.txtLat = txtLat;
		this.txtLng = txtLng;
	}
	

}
