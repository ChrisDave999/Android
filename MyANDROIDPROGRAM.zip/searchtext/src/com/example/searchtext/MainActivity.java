package com.example.searchtext;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.os.Bundle;
import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends Activity implements OnItemClickListener {
	
	ListView lv;
	EditText txtSearch;
	
	//data holders
	ArrayList<String> list = new ArrayList<String>();
	ArrayList<String> source = new ArrayList<String>();
	//adapter
	ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      this.txtSearch = (EditText) this.findViewById(R.id.editText1);
        this.lv	= (ListView) this.findViewById(R.id.listView1);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list);
        this.lv.setAdapter(adapter);
        //populate data reference
        
        this.source.add("Abbadon");
        this.source.add("Axe");
        this.source.add("Gyrocopter");
        this.source.add("Ogre Magi");
        this.source.add("Monkey King");
        this.source.add("Sniper");
        this.source.add("Night Stalker");
        this.source.add("Zeus");
        this.source.add("Earth Shaker");
        this.source.add("Medusa");
        this.source.add("Slark");
        this.source.add("Pudge");
        this.source.add("Naga Siren");
        this.source.add("Chaos Knight");
        this.source.add("Keeper of the light");
        this.source.add("Witch Doctor");
        this.source.add("Lion");
        this.source.add("Wraith King");
        this.source.add("Treant Protector");
        this.source.add("Dragon Knight");
        this.source.add("Lina");
        this.source.add("Crystal Maiden");
        this.source.add("Lycan");
        this.source.add("Ember Spirit");
        this.source.add("Leshrac");
        this.source.add("Pugna");
        this.source.add("Clinkz");
        this.source.add("Weaver");
        this.source.add("Sand King");
        this.source.add("Drow Ranger");
        this.source.add("Wind Ranger");
        this.source.add("Jakiro");
        this.source.add("Venomancer");
        this.source.add("Viper");
        this.source.add("Magnus");
        this.source.add("Nyx Assasin");
        this.source.add("Morphling");
        this.source.add("Shadow Fied");
        this.source.add("Shadow Demon");
        this.source.add("Beast Master");
        this.source.add("Earth Spirit");
        this.source.add("Storm Spirit");
        this.source.add("Drunken Master");
        this.source.add("Elder Titan");
        this.source.add("Sven");
        this.source.add("Lone Druid");
        this.source.add("Visage");
        this.source.add("Alchemist");
        this.source.add("Bloodseeker");
        this.source.add("Anti Mage");
        this.source.add("Invoker");
        this.source.add("Slardar");
        this.source.add("Queen of Pain");
        this.source.add("Undying");
        this.source.add("Enchantress");
        this.source.add("IO");
        this.source.add("Arc Warden");
        this.source.add("Disruptor");
        this.source.add("Chen");
       this.source.add("Underlord");
       this.source.add("Outworld Devourer");
       this.source.add("Luna");
       this.source.add("Mirana");
       this.source.add("Legion Commander");
       this.source.add("Phanthom Assasin");
       this.source.add("Templar Assasin");
       this.source.add("Spectre");
       this.source.add("Phantom Lancer");
       this.source.add("Techies");
       this.source.add("Clockwerk");
       this.source.add("Tinker");
       this.source.add("Puck");
       this.source.add("Centaur Warchief");
       this.source.add("Tiny");
       this.source.add("Warlock");
       this.source.add("Omniknight");
       //this.source.add("");
        
        lv.setOnItemClickListener(this);
        
        txtSearch.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
				// TODO Auto-generated method stub
				list.clear();
			}

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				
				Pattern p =Pattern.compile(arg0.toString());
				for(int i = 0; i < source.size(); i++)
				{
					Matcher m = p.matcher(source.get(i));
					if(m.find()){
						list.add(source.get(i));
						adapter.notifyDataSetChanged();
					
					}
					//adapter.notifyDataSetChanged();
				}
			}});
        
        
        
        
        
        
    }
	@Override
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}


 
    
}
